import { combineReducers } from 'redux';
import { SEND_STATE } from '../actions';

const INITIAL_STATE = {};

const exampleReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
  case SEND_STATE:
    return { ...state, ...action.state };
  default:
    return state;
  }
};

const rootReducer = combineReducers({ exampleReducer });

export default rootReducer;
