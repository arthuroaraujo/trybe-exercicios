export const SEND_STATE = 'SEND_STATE';

export const sendState = (state) => ({
  type: SEND_STATE,
  state,
});

export const SEND_STATE2 = 'SEND_STATE2';

export const sendState2 = (state) => ({
  type: SEND_STATE2,
  state,
});
